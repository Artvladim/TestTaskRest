package netcracker.homework.testTask.service;

import org.springframework.stereotype.Service;

@Service //вся бизнес-логика (все алгоритмика)
public class ShopService {
}
